SKIPUNZIP=0
check_magisk_version() {
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	ui_print "- Module versionCode: $(grep_prop versionCode "${TMPDIR}/module.prop")"
	ui_print "********************************************"
	ui_print "- $(grep_prop description "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "********************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "********************************************"
	fi
}

# 判断是否为 Magisk 环境
if [ "$KSU" ] || [ "$APATCH" ]; then
    echo "检测到 KernelSU 环境，跳过 APK 安装操作。"
else
    echo "未检测到 KernelSU/Apatch 环境，开始执行 APK 安装操作。"

    # 检查 /data/adb/ksud 文件是否存在
    if [ -f "/data/adb/ksud" ]; then
        echo "检测到 ksud 文件，可能为 SukiSU，跳过 APK 安装操作。"
    else
        install_apk() {
            apk_file="$1"
            if [ -f "$apk_file" ]; then
                pm install -r "$apk_file"
                echo "软件安装成功."
            else
                echo "Error: $apk_file 未找到!"
            fi
        }
        install_apk "$MODPATH/KsuWebUI.apk"
    fi
fi

check_required_files() {
	REQUIRED_FILE_LIST="/sys/devices/system/cpu/present"
	for REQUIRED_FILE in $REQUIRED_FILE_LIST; do
		if [ ! -e $REQUIRED_FILE ]; then
			ui_print "********************************************"
			ui_print "! $REQUIRED_FILE 文件不存在"
			ui_print "! 请联系模块作者"
			abort    "********************************************"
		fi
	done
}
extract_bin() {
	ui_print "********************************************"
	if [ "$ARCH" == "arm" ]; then
		cp $MODPATH/bin/armeabi-v7a/AppOpt $MODPATH
	elif [ "$ARCH" == "arm64" ]; then
		cp $MODPATH/bin/arm64-v8a/AppOpt $MODPATH
	elif [ "$ARCH" == "x86" ]; then
		cp $MODPATH/bin/x86/AppOpt $MODPATH
	elif [ "$ARCH" == "x64" ]; then
		cp $MODPATH/bin/x86_64/AppOpt $MODPATH
	else
		abort "! Unsupported platform: $ARCH"
	fi
	ui_print "- Device platform: $ARCH"
	rm -rf $MODPATH/bin
}
remove_sys_perf_config() {
	for SYSPERFCONFIG in $(ls /system/vendor/bin/msm_irqbalance); do
		[[ ! -d $MODPATH${SYSPERFCONFIG%/*} ]] && mkdir -p $MODPATH${SYSPERFCONFIG%/*}
		ui_print "- Config file:$SYSPERFCONFIG"
		touch $MODPATH$SYSPERFCONFIG
	done
}
module_instructions() {
	ui_print "********************************************"
	ui_print "线程规则配置文件路径为："
	ui_print "/data/adb/modules/AppOpt/applist.conf"
	ui_print "------------------------------------------"
	ui_print "修改与添加规则无需重启，即时生效"
	ui_print "********************************************"
	cores=$(for cpus in /sys/devices/system/cpu/cpufreq/*/related_cpus; do 
		[ -f "$cpus" ] && cat "$cpus" | wc -w
	done)
	ui_print "当前$(getprop ro.soc.model)设备为$(nproc)核CPU，规格是：$(echo $cores | tr ' ' '+')"
	ui_print "可用CPU范围为：$(cat /sys/devices/system/cpu/present)"
	ui_print "------------------------------------------"
	ui_print "applist.conf 规则写法示例："
	ui_print "------------------------------------------"
	for policy in /sys/devices/system/cpu/cpufreq/policy*; do
		if [ -f "${policy}/related_cpus" ]; then
			policy_num="${policy##*policy}"
			cpus=$(cat "$policy/related_cpus")
			first_cpu=${cpus%% *}
			last_cpu=${cpus##* }
			if [ "$first_cpu" = "$last_cpu" ]; then
				range=$first_cpu
			else
				range="${first_cpu}-${last_cpu}"
			fi
			ui_print "将 '微信' 绑定到簇 ${policy_num} ：com.tencent.mm=${range}"
		fi
	done
	if grep -q "0-[0-9]*" /sys/devices/system/cpu/present; then
		ui_print "------------------------------------------"
		ui_print "将 '王者荣耀' 的 UnityMain 线程绑定到性能核 ："
		ui_print "com.tencent.tmgp.sgame{UnityMain}=$(cat /sys/devices/system/cpu/present | cut -d- -f2)"
		ui_print "------------------------------------------"
		ui_print "将 '王者荣耀' Unity 开头的所有线程绑定到性能核 ："
		ui_print "com.tencent.tmgp.sgame{Unity*}=$(cat /sys/devices/system/cpu/present | cut -d- -f2)"
	else
		ui_print "------------------------------------------"
		ui_print "将 '王者荣耀' 的 UnityMain 线程绑定到性能核 ："
		ui_print "com.tencent.tmgp.sgame{UnityMain}=$(cat /sys/devices/system/cpu/present)"
		ui_print "------------------------------------------"
		ui_print "将 '王者荣耀' Unity 开头的所有线程绑定到性能核 ："
		ui_print "com.tencent.tmgp.sgame{Unity*}=$(cat /sys/devices/system/cpu/present)"
	fi
	ui_print "------------------------------------------"
	ui_print "更多规则使用说明请参考："
	ui_print "http://AppOpt.suto.top"
	ui_print "********************************************"
}
check_magisk_version
check_required_files
extract_bin
remove_sys_perf_config
module_instructions

# 定义路径
OLD_CONF="/data/adb/modules/AppOpt/applist.conf"
NEW_CONF="$MODPATH/applist.conf"
CONF_FILE="$MODPATH/applist.conf"
BACKUP_DIR="/data/adb/modules/AppOpt/"
# 如果外部旧配置存在
if [ -f "$OLD_CONF" ]; then
    # 备份到 /data/adb/modules/AppOpt/ 目录，命名为 applist.conf.bak
    cp "$OLD_CONF" "${BACKUP_DIR}applist.conf.bak"
    # 额外备份为 applist old.conf
    cp "$OLD_CONF" "${BACKUP_DIR}applist old.conf"
    ui_print "- 检测到旧配置，已备份为 applist.conf.bak 和 applist old.conf 到 /data/adb/modules/AppOpt/"
fi
# 不论旧配置是否存在，都用模块自带的新配置
cp "$NEW_CONF" "$CONF_FILE"
ui_print "- 已使用模块自带的新版 applist.conf"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/*.sh" 0 2000 0755 0755 u:object_r:magisk_file:s0
set_perm_recursive "$MODPATH/AppOpt" 0 2000 0755 0755
