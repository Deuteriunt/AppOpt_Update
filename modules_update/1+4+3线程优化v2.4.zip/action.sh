#!/system/bin/sh

#抄的@Afaraway大佬的代码
CLOUD_MODULE_PROP="https://gitee.com/fanshirusheng/AppOpt/raw/master/applist.conf_update/modul.prop"
CLOUD_CHANGELOG="https://gitee.com/fanshirusheng/AppOpt/raw/master/applist.conf_update/AdaptationListlog.md" 
CLOUD_APP_GAME_LIST="https://gitee.com/fanshirusheng/AppOpt/raw/master/applist.conf_update/applist_game.conf"
CLOUD_APP_COMMON_LIST="https://gitee.com/fanshirusheng/AppOpt/raw/master/applist.conf_update/applist_common.conf"
MODULE_PATH="/data/adb/modules/AppOpt"
MODULE_PROP="${MODULE_PATH}/modul.prop"
APP_LIST="${MODULE_PATH}/applist.conf"
TMP_DIR="/storage/emulated/0/Download"
TMP_APP_GAME_LIST="${TMP_DIR}/applist_game.conf"
TMP_APP_COMMON_LIST="${TMP_DIR}/applist_common.conf"
TMP_APP_LIST="${TMP_DIR}/applist.conf"

log_prefix() {
    echo "[$(date "+%Y-%m-%d %H:%M:%S")]"
}

log_with_timestamp() {
    while IFS= read -r line; do
        echo "$(log_prefix) ${line}"
    done
}

cleanup() {
    echo "$(log_prefix) 缓存已清理..."
    echo "$(log_prefix) 更新流程结束"
    echo "----------------------------------------"
    rm -f "${TMP_APP_LIST}" >/dev/null 2>&1
    rm -f "${TMP_APP_COMMON_LIST}" >/dev/null 2>&1
    rm -f "${TMP_APP_GAME_LIST}" >/dev/null 2>&1
}
trap cleanup EXIT

volume_key_selector() {
    local timeout=15
    local start_time=$(date +%s)
    local key_detected=""
    
    echo "$(log_prefix) 请选择操作："
    echo "$(log_prefix) [音量+] ⬆️确认更新"
    echo "$(log_prefix) [音量-] ⬇️取消更新"
    echo "$(log_prefix) 😵等待用户选择（15秒后自动取消）..."
    
    while [ -z "$key_detected" ]; do
        local current_time=$(date +%s)
        if [ $((current_time - start_time)) -ge $timeout ]; then
            echo "$(log_prefix) 选择超时，自动取消更新"
            return 1
        fi
        
        local key_event=$(getevent -qlc 1 2>/dev/null | 
            awk 'BEGIN{FS=" "} /KEY_VOLUMEUP/{print "UP"; exit} /KEY_VOLUMEDOWN/{print "DOWN"; exit}')
        
        case "$key_event" in
            "UP")
                echo "$(log_prefix) 检测到音量上键"
                key_detected="confirm"
                ;;
            "DOWN")
                echo "$(log_prefix) 检测到音量下键"
                key_detected="cancel"
                ;;
        esac
        sleep 0.2
    done

    [ "$key_detected" = "confirm" ] && return 0 || return 1
}

echo "----------------------------------------"
echo "$(log_prefix) 正在获取设备信息..."
{
    echo "设备型号: $(getprop ro.product.model 2>/dev/null || echo '未知')"
    echo "安卓版本: $(getprop ro.build.version.release 2>/dev/null || echo '未知')"
    echo "系统构建: $(getprop ro.build.display.id 2>/dev/null || echo '未知')"
    magisk_path=$(which magisk 2>/dev/null || echo "/data/adb/magisk/magisk")
    echo "Magisk版本: $(${magisk_path} -v 2>/dev/null || echo '未知')"
} | log_with_timestamp

echo "----------------------------------------"
echo "$(log_prefix) 开始检查版本更新..."
cloud_prop=$(curl -sL "${CLOUD_MODULE_PROP}" || { 
    echo "$(log_prefix) 错误：无法获取云端版本配置文件"
    exit 1
})

cloud_version=$(echo "${cloud_prop}" | grep '^versionCode=' | awk -F'=' '{print $2}')
if [ -z "${cloud_version}" ]; then
    echo "$(log_prefix) 错误：云端版本号格式异常"
    exit 1
fi
echo "$(log_prefix) 云端最新版本号：${cloud_version}"
if [ ! -f "${MODULE_PROP}" ]; then
    echo "$(log_prefix) 错误：本地模块配置文件不存在"
    exit 1
fi
local_version=$(grep '^versionCode=' "${MODULE_PROP}" | awk -F'=' '{print $2}')
if [ -z "${local_version}" ]; then
    echo "$(log_prefix) 错误：本地版本号解析失败"
    exit 1
fi
echo "$(log_prefix) 当前本地版本号：${local_version}"

if [ "${cloud_version}" -gt "${local_version}" ]; then
    echo "$(log_prefix) 检测到新版本"
    echo "$(log_prefix) 正在获取配置更新日志..."
    changelog=$(curl -sL "${CLOUD_CHANGELOG}" || {
        echo "$(log_prefix) 错误：更新日志获取失败"
        exit 1
    })
    echo "$(log_prefix) 更新日志内容："
    echo "----------------------------------------"
    echo "${changelog}" | log_with_timestamp
    echo "----------------------------------------"

    if volume_key_selector; then
        echo "$(log_prefix) 您已确认更新"
    else
        echo "$(log_prefix) 更新流程已取消"
        exit 0
    fi

    echo "$(log_prefix) 开始下载新版配置文件..."
    if ! curl -sL "${CLOUD_APP_GAME_LIST}" -o "${TMP_APP_GAME_LIST}"; then
    echo "$(log_prefix) 错误：第一个配置文件下载失败"
    exit 1
    fi

    if ! curl -sL "${CLOUD_APP_COMMON_LIST}" -o "${TMP_APP_COMMON_LIST}"; then
    echo "$(log_prefix) 错误：第二个配置文件下载失败"
    exit 1
    fi

backup_name1="applist_old.conf"
backup_name2="applist.conf.bak"

echo "$(log_prefix) 正在备份旧版配置文件..."

if ! cp -f "${APP_LIST}" "${MODULE_PATH}/${backup_name1}"; then
    echo "$(log_prefix) 错误：备份 ${backup_name1} 失败"
    exit 1
fi

if ! cp -f "${APP_LIST}" "${MODULE_PATH}/${backup_name2}"; then
    echo "$(log_prefix) 错误：备份 ${backup_name2} 失败"
    exit 1
fi

echo "$(log_prefix) 两个备份成功：${backup_name1}, ${backup_name2}"

    echo "$(log_prefix) 正在应用新版配置文件..."
    
printconf_file_title(){
local file="${1}"
echo ' # Android CPU亲和性设置配置文件
# ===================================#===
# 支持的绑定格式:
# 1. 主进程绑定: packageName=CPU核心范围
#    示例: com.example.app=0-3
#
# 2. 子进程绑定: packageName:processName=CPU核心范围
#    示例: com.example.app:push=0-1
#
# 3. 线程绑定: packageName{threadName}=CPU核心范围
#    示例: com.example.app{RenderThread}=2-4
#
# CPU核心范围格式:
# - 单个核心: 0
# - 连续范围: 0-3
# - 多个范围: 0-1,5-7
# ===================================#===
' > "${file}"
}

#音量键测试
volume_choose(){
while :;do
case $(getevent -qlc 1 | sed -E 's/(.*)(VOLUME.*)([[:space:]]+)(DOWN)/\2/g;s/[[:space:]]//g') in
#音量上键
*VOLUMEUP)
echo "false"
#退出循环
break
;;
#音量下键
*VOLUMEDOWN)
echo "true"
break
;;
esac
	sleep 0.2s
done
}

conf_choose_file(){
local target_file="${1}"
local common_file="${2}"
local game_file="${3}"
[ ! -f "${common_file}" ] && return
printconf_file_title "${target_file}"
if [ -f "${game_file}" ];then
cat << Aloazny >> "${target_file}"

`cat "${game_file}"`

`cat "${common_file}"`

Aloazny
else
cat << Aloazny >> "${target_file}"

`cat "${common_file}"`

Aloazny
fi
}

function config_choose_game_or_comm(){
echo "
# ===================================#===
请按下音量键选择配置
音量上键选择(+): ⬆️日常应用+游戏
音量下键选择(-): ⬇️仅日常应用
# ===================================#===

"
if $(volume_choose) ;then
	conf_choose_file "${TMP_APP_LIST}" "${TMP_APP_COMMON_LIST}"
	echo "- 已选择[日常应用]"
else
	conf_choose_file "${TMP_APP_LIST}" "${TMP_APP_COMMON_LIST}" "${TMP_APP_GAME_LIST}"
	echo "- 已添加[日常应用]+[游戏]"
	echo "- 请删除Asoul Games Optimization"
	echo "- 请关闭scene游戏核心分配"
fi
}

#运行函数
config_choose_game_or_comm
 
    if ! su -c "mv -f ${TMP_APP_LIST} ${APP_LIST}"; then
        echo "$(log_prefix) 错误：配置文件替换失败"
        exit 1
    fi

    echo "$(log_prefix) 正在更新本地版本号..."
    if ! sed -i "s/^versionCode=.*/versionCode=${cloud_version}/" "${MODULE_PROP}"; then
        echo "$(log_prefix) 错误：版本号更新失败"
        exit 1
    fi

    echo "$(log_prefix) 版本更新完成"
    echo "$(log_prefix) 已更新至：${cloud_version}"
else
    echo "$(log_prefix) 当前版本已是最新，无需更新"
fi

# 在脚本结束前暂停5秒钟再自动关闭
echo "$(log_prefix) 脚本将在5秒后自动关闭..."
sleep 5