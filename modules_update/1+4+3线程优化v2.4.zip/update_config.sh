# 定义路径
# 模块配置
OLD_CONF="/data/adb/modules/AppOpt/applist.conf"
# 模块升级目录配置
NEW_CONF="${MODPATH}/applist.conf"
# 定义游戏配置
Game_conf="${MODPATH}/applist_game.conf"
# 定义日用配置
Common_conf="${MODPATH}/applist_common.conf"

update_conf(){
# 如果外部旧配置存在
if [ -f "$OLD_CONF" ]; then
    # 备份到 /data/adb/modules/AppOpt/ 目录，命名为 applist.conf.bak
    cp -af "$OLD_CONF" "${OLD_CONF%/*}/applist.conf.bak"
    # 额外备份为 applist old.conf
    cp -af "$OLD_CONF" "${OLD_CONF%/*}/applist_old.conf"
    # 备份到/data/adb/modules_update/AppOpt/
    cp -rf "${OLD_CONF%/*}/applist.conf.bak" "${NEW_CONF%/*}"
    cp -rf  "${OLD_CONF%/*}/applist_old.conf" "${NEW_CONF%/*}"
    echo "- 检测到旧配置，已备份为 applist.conf.bak 和 applist_old.conf 到 /data/adb/modules/AppOpt/"
fi
# 不论旧配置是否存在，都用模块自带的新配置
[ -f "${OLD_CONF}" ] && cp -rf "$NEW_CONF" "$OLD_CONF"
echo "- 已使用模块自带的新版 applist.conf"
}

#定义配置文件开头
printconf_file_title(){
local file="${1}"
echo ' # Android CPU亲和性设置配置文件
# ===================================#===
# 支持的绑定格式:
# 1. 主进程绑定: packageName=CPU核心范围
#    示例: com.example.app=0-3
#
# 2. 子进程绑定: packageName:processName=CPU核心范围
#    示例: com.example.app:push=0-1
#
# 3. 线程绑定: packageName{threadName}=CPU核心范围
#    示例: com.example.app{RenderThread}=2-4
#
# CPU核心范围格式:
# - 单个核心: 0
# - 连续范围: 0-3
# - 多个范围: 0-1,5-7
# ===================================#===
' > "${file}"
}

#音量键测试
volume_choose(){
while :;do
case $(getevent -qlc 1 | sed -E 's/(.*)(VOLUME.*)([[:space:]]+)(DOWN)/\2/g;s/[[:space:]]//g') in
#音量上键
*VOLUMEUP)
echo "false"
#退出循环
break
;;
#音量下键
*VOLUMEDOWN)
echo "true"
break
;;
esac
	sleep 0.2s
done
}

conf_choose_file(){
local target_file="${1}"
local common_file="${2}"
local game_file="${3}"
[ ! -f "${common_file}" ] && return
printconf_file_title "${target_file}"
if [ -f "${game_file}" ];then
cat << Aloazny >> "${target_file}"

`cat "${game_file}"`

`cat "${common_file}"`

Aloazny
else
cat << Aloazny >> "${target_file}"

`cat "${common_file}"`

Aloazny
fi
}

install_apk() {
#装过webviewui就跳过检测，不然重复安装浪费时间。
[ "$(pm list package io.github.a13e300.ksuwebui)" != "" ] && { echo "- 已安装！" ; return 0; } || echo "- 定位WebUI安装包文件……"
apk_file="$1"
if [ -f "$apk_file" ]; then
	pm install -r "$apk_file"
	echo "- 软件安装成功."
else    
	echo "Error: $apk_file 未找到!"
#	exit 1
fi
}

function config_choose_game_or_comm(){
echo "
# ===================================#===
请按下音量键选择配置
音量上键选择(+): ⬆️日常应用+游戏
音量下键选择(-): ⬇️仅日常应用
# ===================================#===

"
if $(volume_choose) ;then
	conf_choose_file "${NEW_CONF}" "${Common_conf}"
	echo "- 已选择[日常应用]"
else
	conf_choose_file "${NEW_CONF}" "${Common_conf}" "${Game_conf}"
	echo "- 已添加[日常应用]+[游戏]"
	echo "- 请删除Asoul Games Optimization"
	echo "- 请关闭scene游戏核心分配"
fi
}

#运行函数
config_choose_game_or_comm
update_conf

# 判断是否为 Magisk 环境
if magisk -v >/dev/null 2>&1 ; then
    echo "- 未检测到 KernelSU/Apatch 环境，开始执行 APK 安装操作。"
    install_apk "$MODPATH/KsuWebUI.apk"
else
    echo "- 检测到 KernelSU 环境，跳过 APK 安装操作。"
fi

#清理无用文件模块
rm -rf "${MODPATH}/README.md" "${MODPATH}/update_config.sh" "$MODPATH/KsuWebUI.apk" "${MODPATH}/鸣谢名单.md" "${MODPATH}/适配名单.md" "${MODPATH}/applist_game.conf" "${MODPATH}/applist_common.conf"
